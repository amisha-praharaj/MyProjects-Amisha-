const productDetails = document.getElementsByClassName("productDetails");

    async function FetchProducts() {
        try {
            const response = await fetch("https://fakestoreapi.com/products");
            const products = await response.json();
    
            products.forEach((product) => {
                const productDiv = document.createElement("div");
                productDiv.setAttribute('class', 'product');
    
                productDiv.innerHTML = `
                    <div>
                        <span>Name: ${product.title}<span>
                        <span>Price: ${product.price}<span>
                        <span>Description: ${product.description}<span>
                        <span>Category: ${product.category}<span>
                        <span>Image: ${product.image}<span>
                        <span>Rating: ${product.rating.rate}<span>
                        <span>Count: ${product.rating.count}<span>
                    </div>
    
                    <div>
                        <button class="edit" onClick="editProduct('${product.id}')">Edit</button>
                        <button class="delete" onClick="deleteProduct('${product.id}')">Delete</button>
                    </div>
                `;
    
                productDetails.append(productDiv);
            })
    
        } catch (error) {
    
        }
    }
    
    FetchProducts();
    





// const studentList = document.getElementById("studentsList");

// async function FetchStudents() {
//     try {
//         const response = await fetch("https://crudapp-m2nk.onrender.com/api/products");
//         const students = await response.json();

//         students.forEach((student) => {
//             const studentDiv = document.createElement("div");
//             studentDiv.setAttribute('class', 'student');

//             studentDiv.innerHTML = `
//                 <div>
//                     <span>Name: ${student.name}<span>
//                     <span>Email: ${student.email}<span>
//                     <span>College: ${student.college}<span>
//                     <span>Description: ${student.description}<span>
//                 </div>

//                 <div>
//                     <button class="edit" onClick="editStudent('${student._id}')">Edit</button>
//                     <button class="delete" onClick="deleteStudent('${student._id}')">Delete</button>
//                 </div>
//             `;

//             studentList.append(studentDiv);
//         })

//     } catch (error) {

//     }
// }

// FetchStudents();