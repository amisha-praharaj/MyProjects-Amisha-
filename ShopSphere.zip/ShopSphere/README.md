
<h1>Welcome this is my project for visited. That is project name Comforty E-commerce App.</h1>
</br>
</br>
<h2>This project auto layout and full responsive.</h2>
</br>
</br>
<h3>We are used this project. react slider, UX/UI designed Tailwind css. so This project is modern app</h3>
</br>
</br>
<h4>how can install all package you. so All command write here. you just copy and past ok done</h4>

</br>
</br>
<h4>1. How to create react js template with vite?</h4>
<h4>Answer: npm create vite@latest ./ -- --template react. and so give you some condition. you just condition fill up. ok done.</h4>



</br>
</br>
<h4>2. how to install npm package manager?</h4>
<h4>Answer: npm install or i. so copy and past your vscode in terminal. and enter. ok done</h4>


</br>
</br>
<h4>3. how to install react router</h4>
<h4>Answer: npm install react-router. so copy and past your vscode in terminal. and enter. ok done</h4>


</br>
</br>
<h4>4. how to install lucide-react</h4>
<h4>Answer: npm install lucide-react. so copy and past your vscode in terminal. and enter. ok done</h4>



</br>
</br>
<h4>5. how to install tailwind css?</h4>
<h4>Answer: npm install tailwindcss @tailwindcss/vite. and you have visit tailwind css website. so copy and past your in vscode. and enter. ok done</h4>



</br>
</br>
<h4>6. how to install react slick slider?</h4>
<h4>Answer: npm install react-slick slider-carousel. so copy and past your in vscode. and enter. ok done</h4>



</br>
</br>
<h1>Ok All is done</h1>

</br>
</br>
<h1>Thank you so much for visited my github and project. Please Follow me and github follow button clicked</h1>


</br>
</br>
<h1>You subscribe my youtube channel and github follow. my youtube channel link: <a href="https://www.youtube.com/@lifeonthecode">Click On</a></h1>




