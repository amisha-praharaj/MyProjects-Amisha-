const apiKey = "c34bef9ab84977eec0b53736359f97fe";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=germany";

const tempInfo = document.querySelector("#temp");
const cityInfo = document.querySelector("#city");
const humidityInfo = document.querySelector("#percent");
const windInfo = document.querySelector("#km-h");
const searchBox = document.querySelector(".search input");
const searchBtn = document.querySelector(".search button");
async function checkWeather(city) {
    const response = await fetch(`${apiUrl}&q=${city}&appid=${apiKey}`);
    var data = await response.json();

    console.log(data);

    tempInfo.innerHTML = Math.round(data.main.temp) + "°C";
    cityInfo.innerHTML = data.name;
    humidityInfo.innerHTML = data.main.humidity + "%";
    windInfo.innerHTML = data.wind.speed + "km/h";
}

searchBtn.addEventListener("click", () => {
    const city = searchBox.value;
    if (city) {
        checkWeather(city);
    } else {
        alert("Please enter a city name.");
    }
});
