const express = require("express");
// const registerSeller = require("../controllers/sellerController");
// const loginSeller = require("../controllers/sellerController");


const {
    registerSeller,
    loginSeller,
} = require("../controllers/sellerController"); // importing from sellerController

const router = express.Router();

// Register Seller
router.post("/sellerRegister", registerSeller);

// Login Seller
router.post("/sellerLogin", loginSeller);

module.exports = router;