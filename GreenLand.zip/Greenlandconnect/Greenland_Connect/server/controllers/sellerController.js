const mySellerModel = require("../models/SellerModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const registerSeller = async (req, res) => {
    try {
        const { name, email, phone, password } = req.body
        const hashPassword = await bcrypt.hashSync(password, 10)
        const newSeller = new mySellerModel({ name, email, phone, password: hashPassword })
        const existingSeller = await mySellerModel.findOne({ email })
        if (existingSeller) {
            res.status(400).json({ message: "Seller already exists" })
        }
        await newSeller.save()
        res.status(201).json({ message: "Seller registered successfully✅✅", data: newSeller })
    } catch (error) {
        res.status(400).json({ message: error.message })
    }
}

const loginSeller = async (req, res) => {
    try {
        const { email, password } = req.body
        if (!email || !password) {
            return res.status(400).json({ message: "Email and password are required" })
        }

        const existingSeller = await mySellerModel.findOne({ email })
        if (!existingSeller) {
            res.status(404).json({ message: "Seller does not exist" })
        }

        const isMatch = await bcrypt.compare(password, existingSeller.password)
        if (!isMatch) {
            res.status(401).json({ message: "Invalid Password" })            // 401 Unauthorized
        }

        const token = jwt.sign(
            { id: existingSeller._id, email: existingSeller.email }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN }
        )

        res.status(200).json({ message: "Seller logged in successfully✅✅", data: existingSeller, token:token })
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

module.exports = { registerSeller, loginSeller }