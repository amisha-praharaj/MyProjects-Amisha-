import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ViewLands = () => {
  const [getLands, setGetLands] = useState([]);
  const navigate = useNavigate();

  // ✅ Fetch all lands on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("authTokenSeller");
        const response = await axios.get(
          "http://localhost:5000/api/land/getAllLands",{
            headers: {
              Authorization:`Bearer ${token}`
            }
          }
        )
        if (response.data.success) {
          setGetLands(response.data.data);
        }
      } catch (error) {
        console.error("Error fetching lands:", error);
      }
    };
    fetchData();
  }, []);

  // Handle Edit
  const handleEdit = (id) => {
    navigate(`/dashboard/edit-land/${id}`);
  };

  // Handle Delete
  const handleDelete = async (id) => {

    try {
      await axios.delete(`http://localhost:5000/api/land/deleteLand/${id}`);
      alert("Land deleted successfully");
      // Remove deleted land from state
      setGetLands(prev => prev.filter(land => land._id !== id));
    } catch (error) {
      console.error("Error deleting land:", error);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">My Lands</h1>
      <table className="w-full bg-white text-black rounded overflow-hidden">
        <thead className="bg-green-500 text-white">
          <tr>
            <th className="p-2">Title</th>
            <th className="p-2">Price</th>
            <th className="p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {getLands.map((land) => (
            <tr key={land._id} className="text-center border-b">
              <td className="p-2">{land.title}</td>
              <td className="p-2">₹{land.price.toLocaleString()}</td>
              <td className="p-2 space-x-2">
                <button
                  className="bg-blue-500 hover:bg-blue-600 px-2 py-1 rounded text-white"
                  onClick={() => handleEdit(land._id)}
                >
                  Edit
                </button>
                <button
                  className="bg-red-500 hover:bg-red-600 px-2 py-1 rounded text-white"
                  onClick={() => handleDelete(land._id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewLands;




// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Link, useNavigate } from 'react-router-dom'


// const ViewLands = () => {
//   const dummyLands = [
//     { id: 1, title: "Farm Land", price: "₹5,00,000" },
//     { id: 2, title: "Residential Plot", price: "₹8,50,000" },
//   ];

//   const [getLands, setGetLands] = useState(dummyLands);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchData = async () => {
//       try {


//         const response = await axios.get("http://localhost:5000/api/land/getAllLands")
//         console.log("running......");

//         if (response.data.success) {
//           setGetLands(response.data.data)
//         }
//       }
//       catch (error) {
//         console.log(error)
//       }
//     }
//     fetchData()
//   }, [])


//   const handleEdit = (id) => {
//     navigate(`/dashboard/edit-land/${id}`)
//   }



//     const handleDelete = async () => {
//       try {


//         const response = await axios.delete(`http://localhost:5000/api/land/deleteLand/${id}`)
//         alert("Land deleted successfully")
//         navigate("/dashboard/view-lands")
//       }
//       catch (error) {
//         console.log(error)
//       }
//     }


//   return (
//     <div>
//       <h1 className="text-3xl font-bold mb-6">My Lands</h1>
//       <table className="w-full bg-white text-black rounded overflow-hidden">
//         <thead className="bg-green-500 text-white">
//           <tr>
//             <th className="p-2">Title</th>
//             <th className="p-2">Price</th>
//             <th className="p-2">Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {getLands.map((land) => (
//             <tr key={land.id} className="text-center border-b">
//               <td className="p-2">{land.title}</td>
//               <td className="p-2">{land.price}</td>
//               <td className="p-2 space-x-2">
//                 <button className="bg-blue-500 hover:bg-blue-600 px-2 py-1 rounded text-white" onClick={() => handleEdit(land._id)}>Edit</button>
//                 <button className="bg-red-500 hover:bg-red-600 px-2 py-1 rounded text-white" onClick={() => handleDelete(land._id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default ViewLands;